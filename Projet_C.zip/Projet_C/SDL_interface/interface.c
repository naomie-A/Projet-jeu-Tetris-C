// #include <SDL.h> 
// #include <stdio.h> 
// #include <stdlib.h> 
// #include <math.h>
// #include <stdbool.h>


// // //gcc src/interface.c -o bin/prog -I include -L lib -lmingw32 -lSDL2main -lSDL2
// // //gcc interface.c -o prog $(sdl2-config --cflags --libs)
// // //SDL_WINDOW_FULLSCREEN
// // /*
// // SDL_RENDERER_SOFTWARE
// // SDL_RENDERER_ACCELERATED
// // SDL_RENDERER_PRESENTVSYNC
// // SDL_RENDERER_TARGETTEXTURE
// // */

// int
// SDL_RenderDrawCircle(SDL_Renderer * renderer, int x, int y, int radius)
// {
//     int offsetx, offsety, d;
//     int status;


//     offsetx = 0;
//     offsety = radius;
//     d = radius -1;
//     status = 0;

//     while (offsety >= offsetx) {
//         status += SDL_RenderDrawPoint(renderer, x + offsetx, y + offsety);
//         status += SDL_RenderDrawPoint(renderer, x + offsety, y + offsetx);
//         status += SDL_RenderDrawPoint(renderer, x - offsetx, y + offsety);
//         status += SDL_RenderDrawPoint(renderer, x - offsety, y + offsetx);
//         status += SDL_RenderDrawPoint(renderer, x + offsetx, y - offsety);
//         status += SDL_RenderDrawPoint(renderer, x + offsety, y - offsetx);
//         status += SDL_RenderDrawPoint(renderer, x - offsetx, y - offsety);
//         status += SDL_RenderDrawPoint(renderer, x - offsety, y - offsetx);

//         if (status < 0) {
//             status = -1;
//             break;
//         }

//         if (d >= 2*offsetx) {
//             d -= 2*offsetx + 1;
//             offsetx +=1;
//         }
//         else if (d < 2 * (radius - offsety)) {
//             d += 2 * offsety - 1;
//             offsety -= 1;
//         }
//         else {
//             d += 2 * (offsety - offsetx - 1);
//             offsety -= 1;
//             offsetx += 1;
//         }
//     }

//     return status;
// }


// void SDL_RenderFillCircle(SDL_Renderer* rendu, int x0, int y0, int rayon){
// 	int x = rayon;
// 	int y = 0;
// 	int ErreurRayon = 1 - x;
// 	while (x >= y) {
// 		SDL_RenderDrawLine(rendu, x + x0, y + y0, -x + x0, y + y0);
// 		SDL_RenderDrawLine(rendu, y + x0, x + y0, -y + x0, x + y0);
// 		SDL_RenderDrawLine(rendu, -x + x0, -y + y0, x + x0, -y + y0);
// 		SDL_RenderDrawLine(rendu, -y + x0, -x + y0, y + x0, -x + y0);
// 		y++;
// 		if (ErreurRayon < 0)
// 			ErreurRayon += 2 * y + 1;
// 		else {
// 			x--;
// 			ErreurRayon += 2 * (y - x + 1);
// 		    }
// 	    }
//     }



// void SDL_RenderFillLosange(SDL_Renderer* renderer, int x, int y, int size) {
//     SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Couleur rouge

//     for (int i = 0; i <= size; i++) {
//         SDL_RenderDrawLine(renderer, x - i, y - size + i, x + i, y - size + i);
//         SDL_RenderDrawLine(renderer, x - i, y + size - i, x + i, y + size - i);
//     }
// }


// void SDL_RenderDrawLosange(SDL_Renderer* renderer, int x, int y, int size) {
//     SDL_Point points[5];

//     points[0].x = x;
//     points[0].y = y - size;

//     points[1].x = x + size;
//     points[1].y = y;

//     points[2].x = x;
//     points[2].y = y + size;

//     points[3].x = x - size;
//     points[3].y = y;

//     points[4].x = x;
//     points[4].y = y - size;

//     SDL_SetRenderDrawColor(renderer, 0, 0, 0, SDL_ALPHA_OPAQUE); // Couleur rouge

//     SDL_RenderDrawLines(renderer, points, 5);
// }


// void SDL_RenderFillTriangle(SDL_Renderer *renderer, int x, int y, int sideLength) {
//     int halfHeight = (int)(sideLength * sqrt(3) / 2); // Calculate the height of an equilateral triangle

//     // Calculate coordinates of the other two vertices
//     int x2 = x + sideLength;
//     int y2 = y;
//     int x3 = x + sideLength / 2;
//     int y3 = y - halfHeight;

//     // Draw the three sides of the triangle using SDL_RenderDrawLine
//     SDL_RenderDrawLine(renderer, x, y, x2, y2);
//     SDL_RenderDrawLine(renderer, x2, y2, x3, y3);
//     SDL_RenderDrawLine(renderer, x3, y3, x, y);
// }

// void SDL_ExitWithError(const char *message){
//     SDL_Log("ERREUR: %s > %s\n", message, SDL_GetError());
//     SDL_Quit();
//     exit(EXIT_FAILURE);
// }

// int main(int argc, char **argv){

//     SDL_Window *fenetre = NULL;
//     SDL_Renderer *rendu = NULL; 

//     if (SDL_Init(SDL_INIT_VIDEO) != 0){
//         SDL_ExitWithError("Erreur d'initialisation SDL");
//     }
    

//     if (SDL_CreateWindowAndRenderer(1400, 800, 0, &fenetre, &rendu) != 0){
//         SDL_ExitWithError("Impossible de créer la fenêtre et le rendu.");
//     }

//     SDL_SetRenderDrawColor(rendu, 0x80, 0x80, 0x80, SDL_ALPHA_OPAQUE);
//     SDL_RenderClear(rendu);


//     SDL_Rect rectangle={.y=100, .h = 50, .x = 50, .w = 50};
 
//     if(SDL_SetRenderDrawColor(rendu, 255, 255, 255, SDL_ALPHA_OPAQUE) != 0){
//         SDL_ExitWithError("Impossible de changer de couleur."); 
//     }

//     if (SDL_RenderDrawRect(rendu, &rectangle) != 0){
//         SDL_ExitWithError("Impossible de dessiner le rectangle");
//     }

//     if(SDL_SetRenderDrawColor(rendu, 0, 0, 255, SDL_ALPHA_OPAQUE) != 0){
//         SDL_ExitWithError("Impossible de changer de couleur."); 
//     }

//     if (SDL_RenderFillRect(rendu, &rectangle) != 0){
//         SDL_ExitWithError("Impossible de remplir le rectangle");
//     }
//     SDL_SetRenderDrawColor(rendu,0,0,0,SDL_ALPHA_OPAQUE);
//     SDL_RenderDrawRect(rendu,&rectangle);


//     if(SDL_SetRenderDrawColor(rendu, 0, 255, 0, SDL_ALPHA_OPAQUE) != 0){
//         SDL_ExitWithError("Impossible de changer de couleur."); 
//     }

//     SDL_RenderFillCircle(rendu,150,125,25);

//     SDL_SetRenderDrawColor(rendu,0,0,0, SDL_ALPHA_OPAQUE);
//     SDL_RenderDrawCircle(rendu,150,125,25);

//     if(SDL_SetRenderDrawColor(rendu, 255, 0, 0, SDL_ALPHA_OPAQUE) != 0){
//         SDL_ExitWithError("Impossible de changer de couleur."); 
//     }

//     SDL_RenderFillLosange(rendu, 225, 125, 25);
//     SDL_SetRenderDrawColor(rendu, 0,0,0, SDL_ALPHA_OPAQUE);
//     SDL_RenderDrawLosange(rendu, 225, 125, 25);

//     if(SDL_SetRenderDrawColor(rendu, 255, 255, 0, SDL_ALPHA_OPAQUE) != 0){
//         SDL_ExitWithError("Impossible de changer de couleur."); 
//     }

//     SDL_RenderFillTriangle(rendu, 275,150,50);

// //     SDL_RenderPresent(rendu);

    
//     SDL_Event event;

    
//     bool running = true;
//     while(running) {
//         SDL_Event event;
//         while(SDL_PollEvent(&event)) {
//             if(event.type == SDL_QUIT) {
//                 running=false;
//             }
//         }
// }
//     SDL_DestroyRenderer(rendu);
//     SDL_DestroyWindow(fenetre);
//     SDL_Quit();

//     return EXIT_SUCCESS;
// }


