#ifndef LIST_H
	#define LIST_H
	#include "forme.h"
	#include <stdio.h>
	
	typedef struct maillon {
		Forme *val;
		struct maillon *next;
        struct maillon *next_couleur;
		struct maillon *prev_couleur;
		struct maillon *next_lettre;
		struct maillon *prev_lettre;
		} Maillon;

	typedef struct liste {
		int taille;
		Maillon *head;
		Maillon *tail;
		} Liste;


    typedef struct double_list{
		int taille;
		Maillon *head_couleur;
		Maillon *tail_couleur;
        Maillon *head_lettre;
	    Maillon *tail_lettre;
     }Double_Liste;
     
    
	Liste *liste_init(void);
	
    Maillon *Maillon_init(void);

	void afficher_liste(Liste *liste);

    void afficher_liste_couleur(Double_Liste *liste_couleur);

	void afficher_liste_forme(Double_Liste *liste_forme);
	
	void libere_liste(Liste *l);

	void liberation_liste_forme(Double_Liste *LL);

	void liberation_liste_couleur(Double_Liste *LC);
		
    void suppression_3_pieces_debut(Liste *L);

    void suppression_3_pieces_fin(Liste *L);

	void suppression(Liste *L);

    Double_Liste *double_list_init(void);

	Maillon* copier_maillon(Maillon *original);

	void supression_precise(Liste *L, int indice, int cpt, Maillon *M);

	void sup(Liste *L);
	
#endif
