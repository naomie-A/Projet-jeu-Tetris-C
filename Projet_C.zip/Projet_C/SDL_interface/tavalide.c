#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "forme.h"
#include "list.h"
#include "SDL_Forme.h"
#include <stdbool.h>
#include <SDL.h>
#include <math.h>
#include <SDL_ttf.h>


void ajout_maillon_forme(Double_Liste *LL, Maillon *M){ /*est ce vrmt utile de reecire deux fonctions presque identiques alors que seulement la derniere ligne change ? on peut peut etre appeler la fonction et si le joueur a inseré a gauche alors on met  LL->head_lettre=M */
    if (LL->taille==0){
        LL->head_lettre=M; // ici pareil!!!!
        LL->tail_lettre=M;
        M->next_lettre=M;
        M->prev_lettre=M;
        }
     else {
        M->prev_lettre=LL->tail_lettre;
        M->next_lettre=LL->head_lettre;
        LL->tail_lettre->next_lettre=M;
        LL->head_lettre->prev_lettre= M;
    }
    LL->taille++;
}



int alea_lettre(int Letter[]) {
    int nbalea = rand() % 4;
    char letter = Letter[nbalea];
    return letter;
}

int alea_couleur(int Color[]) {
    int nbalea= rand() % 4;
    return Color[nbalea];
}


void initialisation_Liste_5(Liste *list){
    srand(time(0));
    int Color[4] = {31, 32, 33, 34};
    int Letter[4] = {67,76,82,84};
    char lettre = alea_lettre(Letter);
    int couleur =  alea_couleur(Color);
    Forme *forme=creer_forme(lettre,couleur);
    Maillon *M=Maillon_init();
    M -> val= forme;
    list -> head = M;
    list->tail = M;  // Mettez à jour la queue lorsque la liste contient un seul élément
    list->tail->next = list->head;/* on a oublie dinitialiser la queue donc erreur de segmentation */
    (list -> taille) = 1;
    for (int i=0 ; i<4; i++){
        char lettre = alea_lettre(Letter);
        int couleur =  alea_couleur(Color);
        Forme *forme=creer_forme(lettre,couleur);
        Maillon *M=Maillon_init();
        M -> val= forme;
        M->next = list->head;
        list->tail-> next = M;
        list->tail=M;
        (list -> taille) ++; 
    }
}

void ajout_maillon_couleur(Double_Liste *LC, Maillon *M){ /*est ce vrmt utile de reecire deux fonctions presque identiques alors que seulement la derniere ligne change ? on peut peut etre appeler la fonction et si le joueur a inseré a gauche alors on met  LL->head_lettre=M */
    if (LC->taille==0){
        LC->head_couleur=M; // on hesite a mettre du coup ici si on initialise apres la fonction la tete deja!!
        LC->tail_couleur=M;
        M->next_couleur=M;
        M->prev_couleur=M;
    }
    else {
        M->prev_couleur=LC->tail_couleur;
        M->next_couleur=LC->head_couleur;
        LC->tail_couleur->next_couleur=M;
        LC->head_couleur->prev_couleur= M;
    }
    LC->taille++;
}

void decalage_Liste_5(Liste * L){ // fonction qui permet de mettre a jour la liste des 5 prohciane piece a venir en rajoutant un maillon a la fin et en remmettant a jour la tete de la liste 
    int Color[4] = {31, 32, 33, 34};
    int Letter[4] = {67,76,82,84};
    char lettre = alea_lettre(Letter);
    int couleur =  alea_couleur(Color);
    Forme *forme=creer_forme(lettre,couleur);
    Maillon *M=Maillon_init();
    M -> val= forme;
    L->head = L->head->next;
    L->tail->next=M;
    L->tail=M;
    M->next=L->head;
}








Double_Liste *Liste_couleur_char (char couleur, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, SDL_Renderer* rendu){
    switch(couleur){
        case 'R':
            return L_rouge; break;
        case 'V':
            return L_vert; break;
        case 'J':
            return L_jaune; break;
        case 'B':
            return L_bleu; break;
        default:
            //SDL_AffichageTexte(rendu, "Erreur, la couleur n'existe pas", 100, 300);
            return NULL;
            break;
    }

    }
    



Double_Liste *Liste_couleur (Forme *f, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, SDL_Renderer *rendu){
    int couleur=f->couleur;
    if (couleur==31){
        return L_rouge;
        }
    else if (couleur==32){
        return L_vert;
        }
    else if (couleur==33){
        return L_jaune;
        }
    else if (couleur==34){
         return L_bleu;
        }
    else{
         //SDL_AffichageTexte(rendu, "Erreur de saisie", 100, 350);
         return NULL;
    }
    }

Double_Liste *Liste_lettre_char (char lettre, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu ){
    if (lettre=='C'){
        return L_carre;
         }
    else if (lettre=='R'){
        return L_rond;
        }
    else if (lettre=='T'){
        return L_triangle;
        }
    else if (lettre=='L'){
         return L_losange;
        }
    else{
        //SDL_AffichageTexte(rendu, "Erreur, de saisie", 100, 350);
        return NULL;
    }
    return NULL;
    }


Double_Liste *Liste_lettre (Forme *f, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu ){
    char lettre=f->lettre;
    if (lettre=='C'){
        return L_carre;
         }
    else if (lettre=='R'){
        return L_rond;
        }
    else if (lettre=='T'){
        return L_triangle;
        }
    else if (lettre=='L'){
         return L_losange;
        }
    return 0;
    }


void liste_ajout_debut(Liste *L, Forme *forme, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu){
	Maillon *M=Maillon_init();
	M->val= forme;
	M->next = L->head;
	L->head=M;
	L->tail->next = M;
	(L-> taille) ++;
    Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune, rendu);//on parvenait pas a avoir les 4 liste couleur car on ne pouvait pas les reinitialiser a null sachant quil yaavait peut etre des maillons dedans dopnc on les a mis en argument directement
    Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange, rendu);
    ajout_maillon_couleur(L_couleur, M);
    L_couleur->head_couleur = M;
    ajout_maillon_forme(L_lettre, M);// bien verifier que ca marche sinon faire deux fonctions pour g et d.
    L_lettre->head_lettre = M;
	/*dernier element*/
    }

void liste_ajout_fin(Liste *L, Forme *forme, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu){
	Maillon *M=Maillon_init();
	M->val= forme;
	if (L->head == NULL) {
        L->head = M;
        L->tail = M;
 	} else {
	M->next = L->head;
	L->tail-> next = M;
	L->tail=M;
	(L -> taille) ++; 
    Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune, rendu);//on parvenait pas a avoir les 4 liste couleur car on ne pouvait pas les reinitialiser a null sachant quil yaavait peut etre des maillons dedans dopnc on les a mis en argument directement
    Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange, rendu);
    ajout_maillon_couleur(L_couleur, M);
    L_couleur->tail_couleur = M; // bien verifier que ca marche sinon faire deux fonctions pour g et d.
    ajout_maillon_forme(L_lettre, M);
    L_lettre->tail_lettre = M;
    }
} 



// void debut_jeu(Liste *list, Liste *L_5_pièces, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu){
// 	srand(time(0));
//     //Liste *L_5_pièces= liste_init();
// 	char direction;
// 	int Color[4] = {31, 32, 33, 34};
//     int Letter[4] = {67,76,82,84};
//     initialisation_Liste_5(L_5_pièces); // on initilaise nos 5 piece( maillons)
//     Forme *forme=L_5_pièces->head->val;
//     decalage_Liste_5(L_5_pièces); // on a pris le maillon de la tete de la liste pour le mettre dans la liste principale donc il cfaut appeler decalge pour genere un nouveau maillon dans notre liste affichant les 5 prochaines pièces
//     //printf("\033[0;0H"); // on se place en haut à gauche
// 	//printf("\033[2J"); // on efface tout
//     //printf("nouvelle liste generée : ");
//     //SDL_AfficherForme(rendu, forme, 50, 50);
//     //SDL_RenderPresent(rendu);
//     //printf("\n\n");
//     //printf("list 5 piece: ");
//     //afficher_liste_5_pieces(L_5_pièces);
//     //printf("\n");
//     Maillon *M=Maillon_init();
//     M -> val= forme;
//     list -> head = M;
//     list->tail = M;  // Mettez à jour la queue lorsque la liste contient un seul élément
//     list->tail->next = list->head;// on a oublie dinitialiser la queue donc erreur de segmentation 
//     (list -> taille) = 1;
//     Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune, rendu); 
//     Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange, rendu);
//     ajout_maillon_couleur(L_couleur, M);
//     ajout_maillon_forme( L_lettre, M);
//     L_couleur->head_couleur = M; // bien verifier que ca marche sinon faire deux fnction pour g et d.
//     L_lettre->head_lettre = M;
//     //SDL_AfficherListe(rendu, L_5_pièces);
//     }

void debut_jeu(Liste *list, Liste *L_5_pièces, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu){
	srand(time(0));
    //Liste *L_5_pièces= liste_init();
	char direction;
	int Color[4] = {31, 32, 33, 34};
    int Letter[4] = {67,76,82,84};
    // on initilaise nos 5 piece( maillons)
    Forme *forme=L_5_pièces->head->val;
    decalage_Liste_5(L_5_pièces); // on a pris le maillon de la tete de la liste pour le mettre dans la liste principale donc il cfaut appeler decalge pour genere un nouveau maillon dans notre liste affichant les 5 prochaines pièces
    //printf("\033[0;0H"); // on se place en haut à gauche
	//printf("\033[2J"); // on efface tout
    //printf("nouvelle liste generée : ");
    //afficher_forme(forme);
    printf("\n\n");
    //printf("list 5 piece: ");
    //afficher_liste_5_pieces(L_5_pièces);
    //printf("\n");
    Maillon *M=Maillon_init();
    M -> val= forme;
    list -> head = M;
    list->tail = M;  // Mettez à jour la queue lorsque la liste contient un seul élément
    list->tail->next = list->head;// on a oublie dinitialiser la queue donc erreur de segmentation 
    (list -> taille) = 1;
    Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune, rendu); 
    Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange, rendu);
    ajout_maillon_couleur(L_couleur, M);
    ajout_maillon_forme( L_lettre, M);
    L_couleur->head_couleur = M; // bien verifier que ca marche sinon faire deux fnction pour g et d.
    L_lettre->head_lettre = M;
    }


/*void debut_jeu(Liste *list, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange){
	srand(time(0));
    Liste *L_5_pièces= liste_init();
	char direction;
	int Color[4] = {31, 32, 33, 34};
    int Letter[4] = {67,76,82,84};
    initialisation_Liste_5(L_5_pièces, Color, Letter);
    Forme *forme=L_5_pièces->head->val;
    printf("\033[0;0H"); // on se place en haut à gauche
	printf("\033[2J"); // on efface tout
    printf("nouvelle liste generée : ");
    afficher_forme(forme);
    printf("\n");
    Maillon *M=Maillon_init();
    M -> val= forme;
    list -> head = M;
    list->tail = M;  // Mettez à jour la queue lorsque la liste contient un seul élément
    list->tail->next = list->head;// on a oublie dinitialiser la queue donc erreur de segmentation 
    (list -> taille) = 1;
    Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune); 
    Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange);
    ajout_maillon_couleur(L_couleur, M);
    ajout_maillon_forme( L_lettre, M);
    L_couleur->head_couleur = M; // bien verifier que ca marche sinon faire deux fnction pour g et d.
    L_lettre->head_lettre = M;
    }





void debut_jeu(Liste *list, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange){
	srand(time(0));
	char direction;
	int Color[4] = {31, 32, 33, 34};
    int Letter[4] = {67,76,82,84};
    Liste *L_5_pièces= liste_init();
    for (int i=0; i<5; i++){
        char lettre = alea_lettre(Letter);
        int couleur =  alea_couleur(Color);
        Forme *forme=creer_forme(lettre,couleur);
        Maillon *M=Maillon_init();
	    M->val= forme;
	    M->next = L_5_pièces->head;
	    L_5_pièces->tail->next = M;
        L_5_pièces->tail=M;
	    (L_5_pièces-> taille) ++;
    }
    printf("\033[0;0H"); // on se place en haut à gauche
	printf("\033[2J"); // on efface tout
    printf("nouvelle liste generée : ");
    afficher_forme(L_5_pièces->head->val);
    printf("\n");
    Maillon *M=Maillon_init();
    M -> val= L_5_pièces->head->val;
    list -> head = M;
    list->tail = M;  // Mettez à jour la queue lorsque la liste contient un seul élément
    list->tail->next = list->head;// on a oublie dinitialiser la queue donc erreur de segmentation 
    (list -> taille) = 1;
    Double_Liste *L_couleur = Liste_couleur(L_5_pièces->head->val, L_rouge, L_bleu, L_vert, L_jaune); 
    Double_Liste *L_lettre = Liste_lettre(L_5_pièces->head->val, L_carre, L_rond, L_triangle, L_losange);
    ajout_maillon_couleur(L_couleur, M);
    ajout_maillon_forme( L_lettre, M);
    L_couleur->head_couleur = M; // bien verifier que ca marche sinon faire deux fnction pour g et d.
    L_lettre->head_lettre = M;
    }*/




void decalage_list_forme(Double_Liste *liste_forme, Liste *liste){
    int couleur =liste_forme ->head_lettre->val->couleur;
    Maillon *queue=liste_forme ->tail_lettre;
    Maillon *M = liste->head;
    Maillon *Parametre = liste_forme ->head_lettre->next_lettre;
    int j;
    for(j=0;j<liste ->taille; j++){
        if (M->val->lettre == Parametre->val->lettre){
                int c=Parametre -> val->couleur;
                M->val->couleur=c;
                Parametre = Parametre->next_lettre;
            }
        M = M->next;//pas oblige le else on peut reunir
        }
    queue->val->couleur=couleur;
    }


void decalage_list_couleur(Double_Liste *liste_couleur, Liste *liste){
    char lettre=liste_couleur ->head_couleur->val->lettre;
    Maillon *queue = liste_couleur->tail_couleur;
    Maillon *M = liste->head;
    Maillon *Parametre = liste_couleur ->head_couleur->next_couleur;
    int j;
    for(j=0;j<liste ->taille; j++){
        if (M->val->couleur == Parametre->val->couleur ){
            char l=Parametre -> val->lettre;
            M->val->lettre=l;
            Parametre = Parametre->next_couleur;
            }
        M = M->next;//pas oblige le else on peut reunir
        }
    queue->val->lettre=lettre;
    } 



void MAJ_couleur(Liste *liste, Double_Liste *LC, int couleur) {
    /*if (LC != NULL && (LC)->taille > 0) {
        //liberation_liste_couleur(LC);  // Libérer l'ancienne liste si elle existe
        free(LC);
    }*/
    LC->taille=0;
    //LC = double_list_init();  // Initialiser la nouvelle liste
    Maillon *M = liste->head;
    for (int i = 0; i < liste->taille; i++) {
        if (M != NULL && M->val->couleur == couleur) {
            ajout_maillon_couleur(LC, M);
            (LC)->tail_couleur = M;
        }
        M = M->next;
    }
}

void MAJ_forme(Liste *liste, Double_Liste *LL, char lettre) {
    static int nb = 1;  
    /*if (LL != NULL && (LL)->taille > 0) {
       //liberation_liste_forme(LL);  // Libérer l'ancienne liste si elle existe
        free(LL);
    }*/
    LL->taille=0;

   // LL = double_list_init ();  // Initialiser la nouvelle liste
    Maillon *M = liste->head;

    for (int i = 0; i < liste->taille; i++) {
        if (M != NULL && (M->val)->lettre == lettre) {
            ajout_maillon_forme(LL, M);
            (LL)->tail_lettre = M;
        }
        M = M->next;
    }
 
}





void MAJ_generale(Liste *list, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange){
    MAJ_forme(list, L_carre, 'C');
    MAJ_forme(list, L_losange, 'L');
    MAJ_forme(list, L_rond, 'R');
    MAJ_forme(list, L_triangle, 'T');
    MAJ_couleur(list, L_rouge, 31);// jsp si il vaut mieux faire maj genreale ppur couleur et forme ou une globale pcq des fois on recerrer des liste alors quelles etaient deja bien
    MAJ_couleur(list, L_bleu, 34);
    MAJ_couleur(list, L_jaune, 33);
    MAJ_couleur(list, L_vert, 32);
}


/*int Score(int score, Liste *L, int taille, char option){ // loption correspond a comment la suppression a ete faite: s pour suppression simple cad en inserant droite ou gauche et d pour suppression garce a un decalage
    if (option == 's'){
        if ( L->taille==taille- 3){
        return score + 20;
        }
    }
    else if(option == 'd'){
        for (int i=3; i<=L->taille; i++){// jsp vrmt combien de piece peuvent etre supprime dun coup en faisant un decalage donc je fais tt les cas
            if (L->taille==taille-i){
                return score + 50 + 15*(i-3); // si suppression avec decalage alors on a 50 point direct et on rajoute + 15 pour chaque elemnt supprime en plus des 3 pendant les decalage
            }
        }
    }
    return score; // au cas ou ya eu aucune suppression et que le score na pas change

}*/

int Score(int score, Liste *L, int taille, char option){ // loption correspond a comment la suppression a ete faite: s pour suppression simple cad en inserant droite ou gauche et d pour suppression garce a un decalage
    if (option == 's'){
        if ( L->taille==taille- 3){
        return score + 20;
        }
    }
    else if(option == 'd'){
        int elem_supp= taille - L->taille;
        if (elem_supp > 0) { // OU >= 3
            return score + 50 + 15 * (elem_supp - 3);  // si suppression avec decalage alors on a 50 point direct et on rajoute + 15 pour chaque elemnt supprime en plus des 3 pendant les decalage
        }
        }
    return score; // au cas ou ya eu aucune suppression et que le score na pas change

}

/*void choix_decalage(Liste *list, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu) { // jai rajoute une liste principale en argument pour maj liste principale
    char reponse;
    char choix;
    char rep_couleur;
    char rep_forme;
    SDL_Event event;
        //SDL_AffichageTexte(rendu, "Couleur (C) ou Forme (F) ? ", 100, 200);
        if (SDL_PollEvent(&event) != 0) {
                    if (event.type == SDL_QUIT) {
                        SDL_DestroyRenderer(rendu);
                        SDL_Quit();
                     }
        if (event.type == SDL_KEYDOWN) {
        if (event.key.keysym.sym == SDLK_c){
            //SDL_AffichageTexte(rendu, "Couleur R? V, B ou J ?  ? ", 100, 250);
            switch (event.key.keysym.sym) {
                case SDLK_r:
                    rep_couleur = 'R';
                    break;
                case SDLK_j:
                    rep_couleur = 'J';
                    break;
                case SDLK_b:
                    rep_couleur = 'B';
                    break;
                case SDLK_v:
                    rep_couleur = 'V';
                    break;
                default:
                    break;
            }
                Double_Liste *LC = Liste_couleur_char(rep_couleur, L_rouge, L_bleu, L_vert, L_jaune, rendu);
                decalage_list_couleur(LC, list); 
                MAJ_forme(list, L_carre, 'C');
                MAJ_forme(list, L_losange, 'L');
                MAJ_forme(list, L_rond, 'R');
                MAJ_forme(list, L_triangle, 'T');
                SDL_SetRenderDrawColor(rendu, 58, 142, 186, SDL_ALPHA_OPAQUE);
                SDL_RenderClear(rendu);
                SDL_AfficherListe(rendu, list);
                if (list->taille !=0){
                    //SDL_AffichageTexte(rendu, "Pièce :  ", 100, 50);;
                }
            
            else{
                //SDL_AffichageTexte(rendu, "Decalage impossible, Erreur de saisie ", 100, 400);
            }
        }
        
        else if (event.key.keysym.sym == SDLK_f) {
            //SDL_AffichageTexte(rendu, "Forme C? R, L ou T ?  ? ", 100, 250);
             switch (event.key.keysym.sym) {
                case SDLK_t:
                    rep_forme = 'T';
                    break;
                case SDLK_c:
                    rep_forme = 'C';
                    break;
                case SDLK_l:
                    rep_forme = 'L';
                    break;
                case SDLK_r:
                    rep_forme = 'R';
                    break;
                default:
                    break;
            }
                Double_Liste *LL = Liste_lettre_char(rep_forme, L_carre, L_rond, L_triangle, L_losange, rendu);
                decalage_list_forme(LL, list);
                MAJ_couleur(list, L_rouge, 31);// jsp si il vaut mieux faire maj genreale ppur couleur et forme ou une globale pcq des fois on recerrer des liste alors quelles etaient deja bien
                MAJ_couleur(list, L_bleu, 34);
                MAJ_couleur(list, L_jaune, 33);
                MAJ_couleur(list, L_vert, 32);
                //afficher_liste(list);
                if (list->taille !=0){
                    //SDL_AffichageTexte(rendu, "Pièce :  ", 100, 50);;
                }
                

            }
            }
        
        }


        
            //else{
                //SDL_AffichageTexte(rendu, "Decalage impossible, Erreur de saisie ", 100, 400);
        //}
        
        //else {
            //SDL_AffichageTexte(rendu, "Decalage impossible, Erreur de saisie ", 100, 400);
        //}
}
*/


void choix_decalage(Liste *list, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu, SDL_Event event) {
    char rep_couleur ;
    char rep_forme ;
    // Forme *forme;
    // forme ->couleur = 32;
    // forme ->lettre = 'C';
    // SDL_AfficherForme(rendu, forme, 500,500);
            SDL_PollEvent(&event);
            if (event.key.keysym.sym == SDLK_c || event.key.keysym.sym == SDLK_f) {
                SDL_PollEvent(&event);
                if (event.key.keysym.sym == SDLK_c) {
                    switch (event.key.keysym.sym) {
                        case SDLK_r:
                            rep_couleur = 'R';
                            break;
                        case SDLK_j:
                            rep_couleur = 'J';
                            break;
                        case SDLK_b:
                            rep_couleur = 'B';
                            break;
                        case SDLK_v:
                            rep_couleur = 'V';
                            break;
                        default:
                            break;
                    }
                        Double_Liste *LC = Liste_couleur_char(rep_couleur, L_rouge, L_bleu, L_vert, L_jaune, rendu);
                        decalage_list_couleur(LC, list);
                        MAJ_forme(list, L_carre, 'C');
                        MAJ_forme(list, L_losange, 'L');
                        MAJ_forme(list, L_rond, 'R');
                        MAJ_forme(list, L_triangle, 'T');
                        SDL_SetRenderDrawColor(rendu, 58, 142, 186, SDL_ALPHA_OPAQUE);
                        SDL_RenderClear(rendu);
                        SDL_AfficherListe(rendu, list,50, 50, 200);
                        if (list->taille != 0) {
                            // Ajoutez ici le rendu et l'affichage nécessaires
                            // SDL_AffichageTexte(rendu, "Pièce :  ", 100, 50);
                        }
                    
                    //else {
                        // Ajoutez ici le rendu et l'affichage nécessaires
                        // SDL_AffichageTexte(rendu, "Decalage impossible, Erreur de saisie ", 100, 400);
                    //}
                }
                else if (event.key.keysym.sym == SDLK_f) {
                    SDL_PollEvent(&event);
                    switch (event.key.keysym.sym) {
                        case SDLK_t:
                            rep_forme = 'T';
                            break;
                        case SDLK_c:
                            rep_forme = 'C';
                            break;
                        case SDLK_l:
                            rep_forme = 'L';
                            break;
                        case SDLK_r:
                            rep_forme = 'R';
                            break;
                        default:
                            break;
                    }

                        Double_Liste *LL = Liste_lettre_char(rep_forme, L_carre, L_rond, L_triangle, L_losange, rendu);
                        decalage_list_forme(LL, list);
                        MAJ_couleur(list, L_rouge, 31);
                        MAJ_couleur(list, L_bleu, 34);
                        MAJ_couleur(list, L_jaune, 33);
                        MAJ_couleur(list, L_vert, 32);
                        // Afficher la liste si nécessaire
                        if (list->taille != 0) {
                            // SDL_AffichageTexte(rendu, "Pièce :  ", 100, 50);
                        }
                    
                    //else {
                        // Ajoutez ici le rendu et l'affichage nécessaires
                        // SDL_AffichageTexte(rendu, "Decalage impossible, Erreur de saisie ", 100, 400);
                    //}
                }
            }
        
    
    // Ajoutez ici la gestion des erreurs si nécessaire
}

void insertion_list(Liste *list, Liste *L_5_pièces, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange, SDL_Renderer *rendu) {
    Forme *forme;
    srand(time(0));
    char direction;
    int score = 0;
    char txt[50];
    snprintf(txt, sizeof(txt), "SCORE : %d", score);
    int quit = 0;
    SDL_Event event;

    for (; list->taille < 15;) {
        forme = L_5_pièces->head->val;

        if (SDL_PollEvent(&event) != 0) {
            if (event.type == SDL_QUIT) {
                SDL_DestroyRenderer(rendu);
                SDL_Quit();
            }

            SDL_SetRenderDrawColor(rendu, 58, 142, 186, SDL_ALPHA_OPAQUE);
            SDL_RenderClear(rendu);
            SDL_AfficherListe(rendu, list,50, 50, 200);
            //SDL_AfficherForme(rendu, forme, 50, 700,50);
            SDL_AfficherListe(rendu, L_5_pièces, 30, 1000, 50);
            SDL_AfficherTexte(rendu, txt, 50, 50, 25);
            SDL_AfficherTexte(rendu, "TETRIS", 568, 50, 50);
            SDL_RenderPresent(rendu);


            if (event.type == SDL_KEYDOWN) {
                if (event.key.keysym.sym == SDLK_LEFT) {
                    direction = 'G';
                    liste_ajout_debut(list, forme, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange, rendu);
                    int taille = list->taille;
                    sup(list);
                    MAJ_generale(list, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                    score = Score(score, list, taille, 's');
                    snprintf(txt, sizeof(txt), "SCORE : %d", score);
                    decalage_Liste_5(L_5_pièces);
                    SDL_AfficherListe(rendu, L_5_pièces, 30, 1000, 50);
                } else if (event.key.keysym.sym == SDLK_RIGHT) {
                    direction = 'D';
                    liste_ajout_fin(list, forme, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange, rendu);
                    int taille = list->taille;
                    sup(list);
                    MAJ_generale(list, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                    score = Score(score, list, taille, 's');
                    snprintf(txt, sizeof(txt), "SCORE : %d", score);
                    decalage_Liste_5(L_5_pièces);
                } else if (event.key.keysym.sym == SDLK_SPACE) {
                    direction = '0';
                    choix_decalage(list, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange, rendu, event);

                    int supp = 1;
                    while (supp == 1) {
                        int taille = list->taille;
                        sup(list);
                        score = Score(score, list, taille, 'd');
                        snprintf(txt, sizeof(txt), "SCORE : %d", score);
                        if (list->taille == taille) {
                            supp = 0;
                        }
                    }

                    MAJ_generale(list, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                    decalage_Liste_5(L_5_pièces);

                    if (list->taille == 0) {
                        debut_jeu(list, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange, rendu);
                    }
                    MAJ_generale(list, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                }
            }
        }

        if (list->taille == 0) {
            debut_jeu(list, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange, rendu);
        }
    }
}


int main(int argc, char **argv){
    SDL_Renderer *rendu = NULL;
    SDL_Window *fenetre = NULL; 
    if (SDL_Init(SDL_INIT_VIDEO) != 0){
        SDL_ExitWithError("Erreur d'initialisation SDL");
    }

    if (SDL_CreateWindowAndRenderer(1400, 800, 0, &fenetre, &rendu) != 0){
        SDL_ExitWithError("Impossible de créer la fenêtre et le rendu.");
    }

    if(TTF_Init()==-1) 
{
    printf("TTF_Init: %s\n", TTF_GetError());
    exit(2);
}

    SDL_SetRenderDrawColor(rendu, 58, 142, 186, SDL_ALPHA_OPAQUE);
    SDL_RenderClear(rendu);


    int val=0;
    Liste *L_5_pièces = liste_init();
    Double_Liste *L_vert=double_list_init();
    Double_Liste *L_bleu=double_list_init();
    Double_Liste *L_rouge=double_list_init();
    Double_Liste *L_jaune=double_list_init();
    Double_Liste *L_carre=double_list_init();
    Double_Liste *L_triangle=double_list_init();
    Double_Liste *L_losange=double_list_init();
    Double_Liste *L_rond=double_list_init();
    Liste *list = liste_init();
    initialisation_Liste_5(L_5_pièces);
    debut_jeu(list,L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange, rendu);
    insertion_list(list,L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange, rendu);

    SDL_RenderPresent(rendu);

    SDL_Event event;


    
    bool running = true;
    while(running) {
        SDL_Event event;
        while(SDL_PollEvent(&event)) {
            if(event.type == SDL_QUIT) {
                running=false;
            }
        }
    }
    //SDL_RenderClear(rendu);
    SDL_DestroyRenderer(rendu);
    SDL_DestroyWindow(fenetre);
    TTF_Quit();
    SDL_Quit();
    return EXIT_SUCCESS;
}