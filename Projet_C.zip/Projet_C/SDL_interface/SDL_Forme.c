#include <SDL.h> 
#include "forme.h" 
#include "list.h"
#include "SDL_Forme.h"
#include <SDL_ttf.h>
#include <stdbool.h>
#include <math.h> 





void SDL_RenderFillCircle(SDL_Renderer *rendu, int x0, int y0, int rayon){
	int x = rayon;
	int y = 0;
	int ErreurRayon = 1 - x;
	while (x >= y) {
		SDL_RenderDrawLine(rendu, x + x0, y + y0, -x + x0, y + y0);
		SDL_RenderDrawLine(rendu, y + x0, x + y0, -y + x0, x + y0);
		SDL_RenderDrawLine(rendu, -x + x0, -y + y0, x + x0, -y + y0);
		SDL_RenderDrawLine(rendu, -y + x0, -x + y0, y + x0, -x + y0);
		y++;
		if (ErreurRayon < 0)
			ErreurRayon += 2 * y + 1;
		else {
			x--;
			ErreurRayon += 2 * (y - x + 1);
		    }
	    }
    }
void SDL_RenderFillTriangle(SDL_Renderer *rendu, int x, int y, int taille, int rouge, int vert, int bleu){
    const SDL_Vertex v0 = {{x, y + taille}, {rouge,vert,bleu, SDL_ALPHA_OPAQUE} ,{0},};
    const SDL_Vertex v1 = {{x + taille, y + taille}, {rouge,vert,bleu, SDL_ALPHA_OPAQUE}, {0},};
    const SDL_Vertex v2 = {{x + (taille/2), y },{rouge,vert,bleu, SDL_ALPHA_OPAQUE},{0},};

    const SDL_Vertex verts[3] = {v0, v1, v2};

    SDL_RenderGeometry(rendu, NULL, verts, 3, NULL, 0);
}

void SDL_RenderFillLosange(SDL_Renderer* rendu, int x, int y, int size) {

    for (int i = 0; i <= size; i++) {
        SDL_RenderDrawLine(rendu, x - i, y - size + i, x + i, y - size + i);
        SDL_RenderDrawLine(rendu, x - i, y + size - i, x + i, y + size - i);
    }
}

void SDL_ExitWithError(const char *message){
    SDL_Log("ERREUR: %s > %s\n", message, SDL_GetError());
    SDL_Quit();
    exit(EXIT_FAILURE);
}

void SDL_AfficherForme(SDL_Renderer *rendu,Forme *forme, int x,int y, int taille){
    int h = taille/2;
    int rouge=0, vert=0, bleu=0; 
    if (forme->couleur ==31){
        rouge = 255;
        vert = 0;
        bleu = 0;
    }
    else if (forme -> couleur == 32){
        rouge = 0;
        vert = 255;
        bleu = 0;
    }
    else if (forme -> couleur == 33){
        rouge = 255;
        vert = 255;
        bleu = 0;
    }
    else {
        rouge = 0;
        vert = 0;
        bleu = 255;
    }
    if (SDL_SetRenderDrawColor(rendu,rouge, vert, bleu, SDL_ALPHA_OPAQUE)!=0){
        SDL_ExitWithError("Erreur lors de la création de la couleur du rendu");
        
    }
    if (forme -> lettre == 'C'){
        SDL_Rect rectangle ={.y = y-h, .h = taille, .x = x, .w = taille};
        SDL_RenderFillRect(rendu, &rectangle);
    }
    else if (forme -> lettre == 'R'){
        SDL_RenderFillCircle(rendu, (x+h), y, h);
    }
    else if (forme -> lettre == 'L'){
        SDL_RenderFillLosange(rendu, (x+h), y, h);
    }
    else {
        SDL_RenderFillTriangle(rendu, x, (y-h), taille, rouge, vert, bleu);
    }
    
}

void SDL_AfficherListe(SDL_Renderer *rendu, Liste *liste, int taille, int x, int y){
    int i=0;
	Maillon *m = liste->head; //pas besoin dallouer la place car le maillon l-> head existe deja                     
	Forme *forme;
	forme=m->val;
	SDL_AfficherForme(rendu,forme,x,y,taille);
	m=m->next;
    x=x+70;
	while(m!=(liste->head)){
		forme=m->val;
		SDL_AfficherForme(rendu,forme,x,y, taille);
        x=x+70;
		m=m->next;
		}
}


void SDL_AfficherTexte(SDL_Renderer *rendu, const char *message, int x, int y, int taille) {
    // Assurez-vous d'avoir initialisé SDL_ttf avant d'utiliser cette fonction

    // Charger la police Arial de taille spécifiée
    TTF_Font *police = TTF_OpenFont("/System/Library/Fonts/Geneva.ttf", taille);
    if (!police) {
        fprintf(stderr, "Erreur lors du chargement de la police : %s\n", TTF_GetError());
        return;
    }

    // Définir la couleur du texte (blanc ici)
    SDL_Color couleurTexte = {255, 255, 255}; // RGB: (255, 255, 255) pour blanc

    // Rendre le texte en surface
    SDL_Surface *surfaceTexte = TTF_RenderText_Blended(police, message, couleurTexte);
    if (!surfaceTexte) {
        fprintf(stderr, "Erreur lors de la création de la surface de texte : %s\n", TTF_GetError());
        TTF_CloseFont(police);
        return;
    }

    // Définir la position du texte
    SDL_Rect destRect = {x, y, surfaceTexte->w, surfaceTexte->h};

    // Dessiner la surface de texte directement sur le rendu
    SDL_RenderCopy(rendu, SDL_CreateTextureFromSurface(rendu, surfaceTexte), NULL, &destRect);

    // Libérer la surface de texte
    SDL_FreeSurface(surfaceTexte);

    // Fermer la police
    TTF_CloseFont(police);
}








