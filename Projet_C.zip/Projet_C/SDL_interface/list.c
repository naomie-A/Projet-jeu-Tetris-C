#include "list.h"
#include "forme.h"
#include <stdio.h>
#include <stdlib.h>

Liste *liste_init(void){
	Liste *L=malloc(sizeof(Liste));
	if (L==NULL){
		return NULL;
        //perror("Erreur lors de l'allocation du maillon"); choisir et mettre e, debut <errno.h>
        //exit(EXIT_FAILURE);
		}
	else{
		L->taille=0;
		L->head=NULL;
        L->tail=NULL; /*on nest pas sur*/
		return L;
		}
}


Double_Liste *double_list_init(void){
	Double_Liste *L=malloc(sizeof(Double_Liste));
	if (L==NULL){
		return NULL;
        //perror("Erreur lors de l'allocation du maillon"); choisir et mettre e, debut <errno.h>
        //exit(EXIT_FAILURE);
		}
	else{
		L->taille=0;
		L->head_couleur=NULL;
        L->tail_couleur=NULL; /*on nest pas sur*/
        L->head_lettre=NULL;
        L->tail_lettre=NULL; /*on nest pas sur*/
		return L;
		}
}



Maillon *Maillon_init(void){
    Maillon *M=malloc(sizeof(Maillon));
    if (M==NULL){
        return NULL;

	}
	else{
        M->val=NULL;
        M->next_couleur=NULL;
		M->prev_couleur=NULL;
		M->next_lettre=NULL;
		M->prev_lettre=NULL;
        }
    return M;
     }
        



void libere_liste(Liste *l){
	free(l);
	}




void liberation_liste_couleur(Double_Liste *LC){
	if (LC == NULL || LC->taille == 0) {
        return; // verifier si elle est pas deja nulle
    }
	Maillon *M=LC->head_couleur;
	Maillon *temp;
	int taille = LC->taille;
	for (int i=0; i<taille-1; i++){
		temp=M;
		M=M->next_couleur;
		free(temp); // pb car on avait libere le temporaire avant de sauvegarder le maillon suivant
	}
	free(M);
	LC->head_couleur = LC->tail_couleur= NULL;
	LC->taille=0;
}

void liberation_liste_forme(Double_Liste *LL){
	if (LL == NULL || LL->taille == 0) {
        return; // verifier si elle est pas deja nulle
    }
	Maillon *M=LL->head_lettre;
	Maillon *temp;
	for (int i=0; i<LL->taille-1; i++){
		temp=M;
		M=M->next_lettre;
		free(temp); // pb car on avait libere le temporaire avant de sauvegarder le maillon suivant
	}
	free(M);
	LL->head_lettre = LL->tail_lettre= NULL;
	LL->taille=0;
}



void afficher_liste(Liste *liste) {

	int i=0;
	Maillon *m = liste->head; /*pas besoin dallouer la place car le maillon l-> head existe deja*/                       
	Forme *f;
	f=m->val;
	printf("\033[0;0H"); // on se place en haut à gauche
	printf("\033[2J"); // on efface tout
	afficher_forme(f);
	m=m->next;
	while(m!=(liste->head)){
		f=m->val;
		afficher_forme(f);
		m=m->next;
		}
	}

void afficher_liste_couleur(Double_Liste *liste_couleur) {
	if (liste_couleur->taille == 0) {
		printf("La liste couleur est vide.\n");
		return;
	}
	int i=0;
	Maillon *m = liste_couleur->head_couleur; /*pas besoin dallouer la place car le maillon l-> head existe deja*/                       
	Forme *f;
	f=m->val;
	//printf("\033[0;0H"); // on se place en haut à gauche
	//printf("\033[2J"); // on efface tout
	afficher_forme(f);
	m=m->next_couleur;
	while(m!=(liste_couleur->head_couleur)){
		f=m->val;
		afficher_forme(f);
		m=m->next_couleur;
		}
	}


void afficher_liste_forme(Double_Liste *liste_forme) {
	if (liste_forme->taille == 0) {
		printf("La liste couleur est vide.\n");
		return;
	}
	int i=0;
	Maillon *m = liste_forme->head_lettre; /*pas besoin dallouer la place car le maillon l-> head existe deja*/                       
	Forme *f;
	f=m->val;
	//printf("\033[0;0H"); // on se place en haut à gauche
	//printf("\033[2J"); // on efface tout
	afficher_forme(f);
	m=m->next_lettre;
	while(m!=(liste_forme->head_lettre)){
		f=m->val;
		afficher_forme(f);
		m=m->next_lettre;
		}
	}


/*void suppression_3_pieces_debut(Liste *L){
	Maillon *m = L->head;
	if(L->taille>=3){
		if((m->val->lettre==m->next->val->lettre) &&(m->next->val->lettre==m->next->next->val->lettre)){
				Maillon *m2=L->head->next;
				Maillon *m3=L->head->next->next;
				L->head=L->head->next->next->next;
				L->tail->next=L->head;
				L->taille -= 3;  // on a failli oublier de mettre a jour la la taille de la liste car on a enleve trois elements
				
				free(m);
				free(m2);
				free(m3);
				}
				
				
		else if ((m->val->couleur==m->next->val->couleur)&&(m->next->val->couleur==m->next->next->val->couleur)){ 
			
				Maillon *m2=L->head->next;
				Maillon *m3=L->head->next->next;
				L->head=L->head->next->next->next;
				L->tail->next=L->head;
				L->taille-=3;
				free(m);
				free(m2);
				free(m3);
				}
			}
		}


void suppression_3_pieces_fin(Liste *L){
	Maillon *m1 = L->head;
	Maillon *m;
	int i=1;
	while(i<(L->taille)-3){
		m1=m1->next;
		i++;
		}
		m=m1->next;
	if(L->taille>=3){
		if((m->val->lettre==m->next->val->lettre) && (m->next->val->lettre==m->next->next->val->lettre)){
				Maillon *m2=m->next;
				Maillon *m3=m->next->next;
				L->tail=m1;
				L->tail->next=L->head;
				L->taille -= 3; 
				free(m);
				free(m2);
				free(m3);
				}
				
		else if (m->val->couleur==m->next->val->couleur && m->next->val->couleur==m->next->next->val->couleur){
				Maillon *m2=m->next;
				Maillon *m3=m->next->next;
				L->tail=m1;
				L->tail->next=L->head;
				L->taille -= 3;
				free(m);
				free(m2);
				free(m3);
				
			}
		}
	 }
*/

Maillon *trouver_prec(Liste *L, int indice) { 
	Maillon *m=L->head;
	for (int i=0; i<indice-1; i++){
		m=m->next;
	}
	return m;
 }



void supression_precise(Liste *L, int indice, int cpt, Maillon *M){
	Maillon *m=L->head;
	Maillon *memoire=M;
	Maillon *prec= trouver_prec(L, indice); 
	if (M==L->head){ // ou alors indice==0  si on supprime au debut de la liste
		for (int i=0; i<cpt; i++){
			m=m->next;
		}
		L->head=m;
		L->tail->next=L->head;
	}
	else if (indice+cpt==L->taille){ // si on supprime la queue  // pour initialiser la queue on doit trouver le prrecedent du maillon a supprimer
		L->tail=prec;
		L->tail->next=L->head;
	}
	else{
		for (int i=0; i<cpt; i++){ // si on supprime qq part au milieu de la liste
			memoire=memoire->next;
			}
		prec->next=memoire;
		}
	L->taille=L->taille-cpt;
	Maillon *sup;
	for (int i=0; i<cpt; i++){ 
		sup= M;
		M=M->next;
		free(sup);
	}


 }

void sup(Liste *L){
	Maillon *m = L->head;
	int indice;
	int i =0;
	int taille=L->taille;
	//if (L->taille>=3){
		while(i< taille){
			int cpt=1;
			int cpt2=1;
			Maillon *m1=m; // sauvegarder le debut pour reparcouriri a partir de ce maillon la lla couleur
			Maillon *m2=m;
			while (m1->val->lettre==m1->next->val->lettre && m1!=L->tail) {
				cpt++;
				m1=m1->next;
			}
			while (m2->val->couleur==m2->next->val->couleur && m2!=L->tail) {
				cpt2++;
				m2=m2->next;
				}
			Maillon * M=m; // garder en memire pouyr le mettre en argument dans supp precise
			indice =i;
			if (cpt2>=3 || cpt>=3){
				if (cpt>cpt2){
					i=i+cpt;
					m=m1->next;
					supression_precise(L, indice, cpt, M);
					
				}
				else{
					i=i+cpt2;
					m=m2->next;
					supression_precise(L, indice, cpt2, M);
				}
			}
			else{ 
				m=m->next;
				i++;
			}
		}
	}


	




		

		
		
