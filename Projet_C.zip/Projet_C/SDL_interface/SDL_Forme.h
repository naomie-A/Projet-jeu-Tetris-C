#ifndef SDL_FORME_H
    #define SDL_FORME_H
        #include <stdio.h>
        #include <SDL.h>
        #include "forme.h"
        #include "list.h"
        #include <math.h>
        #include <SDL_ttf.h>
        #include <stdbool.h>



        void SDL_RenderFillCircle(SDL_Renderer* rendu, int x0, int y0, int rayon);
        void SDL_RenderFillTriangle(SDL_Renderer *rendu, int x, int y, int taille, int rouge, int vert, int bleu);
        void SDL_RenderFillLosange(SDL_Renderer* rendu, int x, int y, int size);
        void SDL_ExitWithError(const char *message);
        void SDL_AfficherForme(SDL_Renderer *rendu,Forme *forme, int x, int y, int taille);
        void SDL_AfficherListe(SDL_Renderer *rendu, Liste *liste, int taille, int x, int y);
        void SDL_AfficherTexte(SDL_Renderer *rendu, const char *message, int x, int y, int taille);
        //void SDL_AffichageTexte(SDL_Renderer* renderer, const char* texte, int x, int y);

#endif