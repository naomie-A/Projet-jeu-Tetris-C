#include "list.h"
#include "forme.h"
#include <stdio.h>
#include <stdlib.h>


Maillon *Maillon_init(void){
    Maillon *M=malloc(sizeof(Maillon));
    if (M==NULL){
        return NULL;
	}
	else{
        M->val=NULL;
		M->suiv=NULL;
        M->suiv_couleur=NULL;
		M->prec_couleur=NULL;
		M->suiv_lettre=NULL;
		M->prec_lettre=NULL;
    }
    return M;
}


Liste *liste_init(void){
	Liste *L=malloc(sizeof(Liste));
	if (L==NULL){
		return NULL;
	}
	else{
		L->taille=0;
		L->tete=NULL;
        L->queue=NULL; 
		return L;
	}
}


Double_Liste *double_liste_init(void){
	Double_Liste *L=malloc(sizeof(Double_Liste));
	if (L==NULL){
		return NULL;
	}
	else{
		L->taille=0;
		L->tete_couleur=NULL;
        L->queue_couleur=NULL; 
        L->tete_lettre=NULL;
        L->queue_lettre=NULL; 
		return L;
	}
}


void liberation_liste(Liste *L){
	if (L == NULL || L->taille == 0) {
        return; // verifier si elle est pas deja nulle
    }
	Maillon *M=L->tete;
	Maillon *temp;
	int taille = L->taille;
	for (int i=0; i<taille; i++){
		temp=M;
		Forme *f=temp->val;
		M=M->suiv;
		free(temp); 
		libere_forme(f);		
	}
	L->tete = L->queue= NULL;
	L->taille=0;
}


void afficher_liste(Liste *liste) {
	Maillon *m = liste->tete;                      
	Forme *f;
	f=m->val;
	printf("\033[0;0H"); // on se place en haut à gauche
	printf("\033[2J"); // on efface tout
	afficher_forme(f);
	m=m->suiv;
	while(m!=(liste->tete)){
		f=m->val;
		afficher_forme(f);
		m=m->suiv;
	}
}

void afficher_liste_5_pieces(Liste *liste) {
	Maillon *m = liste->tete;                      
	Forme *f;
	f=m->val;
	afficher_forme(f);
	m=m->suiv;
	while(m!=(liste->tete)){
		f=m->val;
		afficher_forme(f);
		m=m->suiv;
	}
}


Maillon *trouver_prec(Liste *L, int indice) { 
	Maillon *m=L->tete;
	for (int i=0; i<indice-1; i++){
		m=m->suiv;
	}
	return m;
}


void supression_precise(Liste *L, int indice, int cpt, Maillon *M){
	Maillon *m=L->tete;
	Maillon *memoire=M;
	Maillon *prec= trouver_prec(L, indice); 
	if (M==L->tete){ //  si on supprime au debut de la liste (ou indice==0)
		for (int i=0; i<cpt; i++){
			m=m->suiv;
		}
		L->tete=m;
		L->queue->suiv=L->tete;
	}
	else if (indice+cpt==L->taille){ // si on supprime la queue  
		L->queue=prec; //pour initialiser la queue on doit trouver le maillon précédent du maillon a supprimer pour faire pointer son suivant vers la tete de la liste
		L->queue->suiv=L->tete;
	}
	else{
		for (int i=0; i<cpt; i++){ // si on supprime quelque part au milieu de la liste
			memoire=memoire->suiv;
			}
		prec->suiv=memoire;
		}
	L->taille=L->taille-cpt;
	Maillon *sup;
	for (int i=0; i<cpt; i++){ 
		sup= M;
		Forme *forme = sup -> val;
		M=M->suiv;
		free(sup);
		libere_forme(forme);
	}
}


void sup(Liste *L){
		Maillon *m = L->tete;
		int indice; //variable stockant l'indice du premier élément a supprimer pour chaque suppression
		int i =0;
		int taille=L->taille;
		while(i< taille){
			int cpt=1; // compteur stockant le nombre consecutifs de formes
			int cpt2=1;// compteur stockant le nombre consecutifs de couleurs
			Maillon *m1=m; // sauvegarder le debut pour parcourir les forme a partir de ce maillon 
			Maillon *m2=m; 
			while (m1->val->lettre==m1->suiv->val->lettre && m1!=L->queue) {
				cpt++;
				m1=m1->suiv;
			}
			while (m2->val->couleur==m2->suiv->val->couleur && m2!=L->queue) {
				cpt2++;
				m2=m2->suiv;
			}
			Maillon * M=m; // garder en memoire pour le mettre en argument dans supp precise
			indice =i;
			if (cpt2>=3 || cpt>=3){ 
				if (cpt>cpt2){ // si le nombre de formes consécutives est superieur au nombre de couleur consecutives
					i=i+cpt; // on incremente le compteur i du nombre d'elements a supprimer
					m=m1->suiv;
					supression_precise(L, indice, cpt, M);// permet de supprimer les elements de la liste grace a la position dans la liste, le nombre délements quil faut supprimer etc..
				}
				else{
					i=i+cpt2;
					m=m2->suiv;
					supression_precise(L, indice, cpt2, M);
				}
			}
			else{ 
				m=m->suiv;
				i++;
			}
		}
}


	




		

		
		



		

		
		

