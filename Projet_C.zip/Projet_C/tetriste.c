#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "forme.h"
#include "list.h"


void ajout_maillon_couleur(Double_Liste *LC, Maillon *M){ //on a cree une seule fonction pour droite et gauche car elles sont presques identiques, a lexception de  LL->tete_lettre=M pour gauche, et LL->tete_lettre = M pour droite, qu'on rajoutera en dehors de la fonction
    if (LC->taille==0){
        LC->tete_couleur=M; 
        LC->queue_couleur=M;
        M->suiv_couleur=M;
        M->prec_couleur=M;
    }
    else {
        M->prec_couleur=LC->queue_couleur;
        M->suiv_couleur=LC->tete_couleur;
        LC->queue_couleur->suiv_couleur=M;
        LC->tete_couleur->prec_couleur= M;
    }
    LC->taille++;
}


void ajout_maillon_forme(Double_Liste *LL, Maillon *M){ 
    if (LL->taille==0){
        LL->tete_lettre=M; 
        LL->queue_lettre=M;
        M->suiv_lettre=M;
        M->prec_lettre=M;
        }
     else {
        M->prec_lettre=LL->queue_lettre;
        M->suiv_lettre=LL->tete_lettre;
        LL->queue_lettre->suiv_lettre=M;
        LL->tete_lettre->prec_lettre= M;
    }
    LL->taille++;
}


int alea_lettre(int Lettre[]) { //génère une forme aléatoire
    int nbalea = rand() % 4;
    char lettre = Lettre[nbalea];
    return lettre;
}

int alea_couleur(int Couleur[]) { //génère une couleur aléatoire
    int nbalea= rand() % 4;
    return Couleur[nbalea];
}


Double_Liste *Liste_couleur_char (char couleur, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune){ // retourne la double liste couleur correspondant au choix de l'utilsateur lors du décalage
    switch(couleur){
        case 'R':
            return L_rouge; break;
        case 'V':
            return L_vert; break;
        case 'J':
            return L_jaune; break;
        case 'B':
            return L_bleu; break;
        default:
            printf("Erreur, la couleur n'existe pas");
            return NULL;
            break;
    }
}


Double_Liste *Liste_couleur (Forme *f, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune){ //retourne la double liste couleur correpondant a la couleur de la forme mis en argument
    int couleur=f->couleur;
    if (couleur==31){
        return L_rouge;
        }
    else if (couleur==32){
        return L_vert;
        }
    else if (couleur==33){
        return L_jaune;
        }
    else if (couleur==34){
         return L_bleu;
        }
    else{
         printf("errreur de saisie");
         return NULL;
    }
}


Double_Liste *Liste_lettre_char (char lettre, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange ){ // retourne la double liste forme correspondant au choix de l'utilsateur lors du décalage
    if (lettre=='C'){
        return L_carre;
         }
    else if (lettre=='R'){
        return L_rond;
        }
    else if (lettre=='T'){
        return L_triangle;
        }
    else if (lettre=='L'){
         return L_losange;
        }
    else{
        printf("erreur");
        return NULL;
        }
    return NULL;
}


Double_Liste *Liste_lettre (Forme *f, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange ){//retourne la double liste lettre correpondant a la lettre de la forme mis en argument
    char lettre=f->lettre;
    if (lettre=='C'){
        return L_carre;
         }
    else if (lettre=='R'){
        return L_rond;
        }
    else if (lettre=='T'){
        return L_triangle;
        }
    else if (lettre=='L'){
         return L_losange;
        }
    return 0;
}


void liste_ajout_debut(Liste *L, Forme *forme, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange){ // insère un maillon au debut de trois listes en meme temps : la liste principale, la liste couleur et la liste forme associées
	Maillon *M=Maillon_init();
	M->val= forme;
    if (L->tete == NULL) {
        L->tete = M;
        L->queue = M;
 	} 
    else {
        M->suiv = L->tete;
        L->tete=M;
        L->queue->suiv = M;
        (L-> taille) ++;
        Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune);
        Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange);
        ajout_maillon_couleur(L_couleur, M);
        L_couleur->tete_couleur = M; // on a rajoute cette instruction car elle ne fait pas partie de la fonction ajout_maillon. Dans cette fonctionon ajoute le maillon au debut, donc le maillon devient la tete de la liste.
        ajout_maillon_forme(L_lettre, M);
        L_lettre->tete_lettre = M; // De meme, on a rajoute cette instruction car elle ne fait pas partie de la fonction ajout_maillon pour eviter de daire deux fonctions
    }
}


void liste_ajout_fin(Liste *L, Forme *forme, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange){// insère un maillon a la find de trois listes simultanément : la liste principale, la liste couleur et la liste forme associées
	Maillon *M=Maillon_init();
	M->val= forme;
	if (L->tete == NULL) {
        L->tete = M;
        L->queue = M;
 	} else {
	M->suiv = L->tete;
	L->queue-> suiv = M;
	L->queue=M;
	(L -> taille) ++; 
    Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune);
    Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange);
    ajout_maillon_couleur(L_couleur, M);
    L_couleur->queue_couleur = M; // on rajoute le maillon à la fin donc le maillon devient la queue
    ajout_maillon_forme(L_lettre, M);
    L_lettre->queue_lettre = M;
    }
} 


void initialisation_Liste_5(Liste *liste){
    int Couleur[4] = {31, 32, 33, 34};
    int Lettre[4] = {67,76,82,84};
    char lettre = alea_lettre(Lettre);
    int couleur =  alea_couleur(Couleur);
    Forme *forme=creer_forme(lettre,couleur); // génère une pièce à partir de la lettre et de la couleur génerés aléatoirement
    Maillon *M=Maillon_init();
    M -> val= forme;
    liste -> tete = M;
    liste->queue = M;  
    liste->queue->suiv = liste->tete;
    (liste -> taille) = 1;
    srand(time(0)); //permet de ne pas géneréer toujours les meme pièces
    for (int i=0 ; i<4; i++){
        char lettre = alea_lettre(Lettre);
        int couleur =  alea_couleur(Couleur);
        Forme *forme=creer_forme(lettre,couleur);
        Maillon *M=Maillon_init();
        M -> val= forme; // les 5 lignes suivantes permettent d'insérer une pièce dans la liste en modifiant les pointeurs
        M->suiv = liste->tete;
        liste->queue-> suiv = M;
        liste->queue=M;
        (liste -> taille) ++; 
    }
}


void decalage_Liste_5(Liste * L){ // fonction qui permet de mettre a jour la liste des 5 prochaines pieces en rajoutant un maillon a la fin de la liste, en supprimmant la tete et en la remmettant a jour  
    int Couleur[4] = {31, 32, 33, 34};
    int Lettre[4] = {67,76,82,84};
    char lettre = alea_lettre(Lettre);
    int couleur =  alea_couleur(Couleur);
    Forme *forme=creer_forme(lettre,couleur);
    Maillon *M=Maillon_init();
    Maillon *sup=L->tete; // garde en memoire la tete de la liste pour pouvoir le libérer à la fin
    M -> val= forme;
    L->tete = L->tete->suiv; // décale la tete de la liste au deuxieme élement
    L->queue->suiv=M;
    L->queue=M; // rajoute le nouveau maillon à la fin de la liste
    M->suiv=L->tete;
    free(sup);
}



void debut_jeu(Liste *liste, Liste *L_5_pièces, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange){ // permet de génerer notre premiere pièce du jeu car inutile de demander a l'utilisateur de choisir droite ou gauche pour cette pièce
	int Couleur[4] = {31, 32, 33, 34};
    int Lettre[4] = {67,76,82,84};
    char lettre = alea_lettre(Lettre);
    int couleur =  alea_couleur(Couleur);
    Forme *forme=creer_forme(lettre, couleur);
    // on a pris le maillon de la tete de la liste pour le mettre dans la liste principale donc il cfaut appeler decalge pour genere un nouveau maillon dans notre liste affichant les 5 prochaines pièces
    printf("\033[0;0H"); 
    printf("\033[2J"); 
    printf("nouvelle liste generée : ");
    afficher_forme(forme);
    printf("\n\n");
    Maillon *M=Maillon_init();
    M -> val= forme;//on rajoute le maillon dans la liste principale dans les prochaines lignes
    liste -> tete = M; 
    liste->queue = M; 
    liste->queue->suiv = liste->tete;
    (liste -> taille) = 1;
    Double_Liste *L_couleur = Liste_couleur(forme, L_rouge, L_bleu, L_vert, L_jaune); 
    Double_Liste *L_lettre = Liste_lettre(forme, L_carre, L_rond, L_triangle, L_losange);
    ajout_maillon_couleur(L_couleur, M); //on rajoute le maillon dans la liste couleur
    ajout_maillon_forme( L_lettre, M);//on rajoute le maillon dans la liste forme
    L_couleur->tete_couleur = M;
    L_lettre->tete_lettre = M;
}


void decalage_liste_forme(Double_Liste *liste_forme, Liste *liste){// permet de décaler les formes
    int couleur =liste_forme ->tete_lettre->val->couleur;
    Maillon *queue=liste_forme ->queue_lettre;
    Maillon *M = liste->tete;
    Maillon *Parametre = liste_forme ->tete_lettre->suiv_lettre;// on stocke le deuxieme maillon de la double liste forme pour commencer a la parcourir a partir de ce maillon ci
    int j = 0;
    while (j < liste->taille){
        if (M->val->lettre == Parametre->val->lettre){ // on parcourt la liste principale et la liste forme a partir de son deuxieme maillon et on modifie la couleur du maillon de la liste principale des que les deux maillons ont la meme forme 
                int c=Parametre -> val->couleur; // on stocke dans une variable la couleur car sinon en affectant directement, la forme des deux maillons seraient toujours identiques, ce qui causerait des problemes 
                M->val->couleur=c;
                Parametre = Parametre->suiv_lettre;
        }
        j++;
        M = M->suiv;
    }
    queue->val->couleur=couleur;
}


void decalage_liste_couleur(Double_Liste *liste_couleur, Liste *liste){ // permet de décaler les couleurs
    char lettre=liste_couleur ->tete_couleur->val->lettre;
    Maillon *queue = liste_couleur->queue_couleur;
    Maillon *M = liste->tete;
    Maillon *Parametre = liste_couleur ->tete_couleur->suiv_couleur; // on stocke le deuxieme maillon de la double liste couleur pour commencer a la parcourir a partir de ce maillon ci
    int j = 0;
    while (j < liste->taille){
        if (M->val->couleur == Parametre->val->couleur ){
            char l=Parametre -> val->lettre; // on stocke dans une variable la lettre, sinon la forme des deux maillons seraient toujours identiques, ce qui causerait des problemes 
            M->val->lettre=l;
            Parametre = Parametre->suiv_couleur;
        }
        j++;
        M = M->suiv;
    }
    queue->val->lettre=lettre;
 } 


void MAJ_couleur(Liste *liste, Double_Liste *LC, int couleur) { 
    LC->taille=0; // pour recrééer la liste
    Maillon *M = liste->tete;
    for (int i = 0; i < liste->taille; i++) { //on parcourt la liste principale et des qu'un maillon a la couleur souhaitee on le rajoute dans la double liste couleur
        if (M != NULL && M->val->couleur == couleur) {
            ajout_maillon_couleur(LC, M);
            (LC)->queue_couleur = M;
        }
        M = M->suiv;
    }
}

void MAJ_forme(Liste *liste, Double_Liste *LL, char lettre) {  
    LL->taille=0; // pour recrééer la liste
    Maillon *M = liste->tete;
    for (int i = 0; i < liste->taille; i++) { //on parcourt la liste principale et des qu'un maillon a la forme souhaitee on le rajoute dans la double liste forme
        if (M != NULL && (M->val)->lettre == lettre) { 
            ajout_maillon_forme(LL, M);
            (LL)->queue_lettre = M;
        }
        M = M->suiv;
    }
}


void MAJ_generale(Liste *liste, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange){
    MAJ_forme(liste, L_carre, 'C');
    MAJ_forme(liste, L_losange, 'L');
    MAJ_forme(liste, L_rond, 'R');
    MAJ_forme(liste, L_triangle, 'T');
    MAJ_couleur(liste, L_rouge, 31);
    MAJ_couleur(liste, L_bleu, 34);
    MAJ_couleur(liste, L_jaune, 33);
    MAJ_couleur(liste, L_vert, 32);
}

void liberation_generale(Liste *L, Liste *L_5_pieces, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange) { // fonction permettant de liberer toute les maillons, et les listes créées a la toute fin du jeu
    liberation_liste(L);
    liberation_liste(L_5_pieces);
    free(L_rouge);
    free(L_bleu);
    free(L_vert);
    free(L_jaune);
    free(L_carre);
    free(L_rond);
    free(L_triangle);
    free(L_losange);
    free(L);
    free(L_5_pieces);
}


int Score(int score, Liste *L, int taille, char option){ // l'option correspond au choix de l'utilisateur: s pour suppression simple (insertion droite gauche) et d pour suppression grace a un decalage
    if (option == 's'){
        if ( L->taille==taille- 3){
            return score + 20; // si suppression simple on rajoute 20 points
        }
    }
    else if(option == 'd'){
        int elem_supp= taille - L->taille; // stocke le nombre délements supprimés
        if (elem_supp > 0) { 
            return score + 50 + 15 * (elem_supp - 3);  // si suppression avec decalage alors on rajoute 50 point et + 15 pour chaque element supprimé en plus des 3 pièces
        }
    }
    return score; // au cas ou il n'y a eu aucune suppression et que le score n'a pas éte modifié
}


void choix_decalage(Liste *liste, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange) { // jai rajoute une liste principale en argument pour maj liste principale
    char choix;
    char rep_couleur;
    char rep_forme;
        printf("couleur(C) ou forme(F)");
       	scanf(" %c", &choix);  
        if (choix == 'C' || choix == 'c') {
            printf("couleur? R, J, B, ou V ");
            scanf(" %c", &rep_couleur);
            if (rep_couleur=='R' || rep_couleur=='J' || rep_couleur=='B' || rep_couleur=='V'){
                Double_Liste *LC = Liste_couleur_char(rep_couleur, L_rouge, L_bleu, L_vert, L_jaune);
                if (LC->taille != 0){
                    decalage_liste_couleur(LC, liste); 
                    MAJ_forme(liste, L_carre, 'C');
                    MAJ_forme(liste, L_losange, 'L');
                    MAJ_forme(liste, L_rond, 'R');
                    MAJ_forme(liste, L_triangle, 'T');
		        }
		
            }
            else{
                printf("Décalage impossible car erreur de saisie... \n\n");
            }
        } 
        else if (choix == 'F' || choix == 'f') {
            printf("forme? C, R, T, ou L");
            scanf(" %c", &rep_forme);
            if (rep_forme=='R' || rep_forme=='C' ||  rep_forme=='T' || rep_forme=='L'){
                Double_Liste *LL = Liste_lettre_char(rep_forme, L_carre, L_rond, L_triangle, L_losange);
                if (LL->taille != 0){
                    decalage_liste_forme(LL, liste);
                    MAJ_couleur(liste, L_rouge, 31);
                    MAJ_couleur(liste, L_bleu, 34);
                    MAJ_couleur(liste, L_jaune, 33);
                    MAJ_couleur(liste, L_vert, 32);
                }
            }
            else{
                printf("Décalage impossible car erreur de saisie... \n\n");
            }
        }
        else {
            printf("Décalage impossible car erreur de saisie... \n\n");
        }
}


void sauvegarde_liste(FILE *f, Liste *L) {
    Maillon *M = L->tete;
    for (int i=0 ; i<L->taille; i++) {
        fprintf(f, "%c %d ", M->val->lettre, M->val->couleur); // écris les informations du maillon dans le fichier : couleur et forme.
        fprintf(f, "\n");
        M = M->suiv;
    }
    fprintf(f, "\n"); //saut permettant de séparer les deux listes pour pouvoir bien recharger le jeu ensuite
}


void sauvegarde_jeu(const char *nomfichier, int score, Liste *liste, Liste *L_5_pièces) { // sauvegarde le score, l'etat de la liste principale et de la liste des 5 pièces a la fin du jeu, dans un fichier
    FILE *f = fopen(nomfichier, "w");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier \n");
        return;
    }
    fprintf(f, "%d\n", score);
    sauvegarde_liste(f, liste);
    sauvegarde_liste(f, L_5_pièces);
    fclose(f);
}


void liste_ajout_fin_L_5_pieces(Liste *L, Forme *forme){ // fonction créée pour pouvoir rajouter facilement les maillons dans la liste des 5 pièces dans la fonction charger_jeu
	Maillon *M=Maillon_init();
	M->val= forme;
	if (L->tete == NULL) {
        L->tete = M;
        L->queue = M;
 	} 
    else {
        M->suiv = L->tete;
        L->queue-> suiv = M;
        L->queue=M;
        (L -> taille) ++; 
    }
} 


void charger_jeu(const char *nomfichier, int *score, Liste *liste, Liste *L_5_pièces, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange) {
    FILE *f = fopen(nomfichier, "r");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier \n");
        return;
    }
    char ligne[200];
    fgets(ligne, sizeof(ligne), f); // on met dans une variable car sinon le resultat de fgets est inutilisé et cela créait un warning
    sscanf(ligne, " %d ", &*score); //lecture du score
    char lettre;
    int couleur;
    while (fgets(ligne, sizeof(ligne), f)!=NULL && ligne[0]!='\n'){ //lecture de la première liste 
        if (sscanf(ligne, "%c %d ", &lettre, &couleur)==2){ // on prend les elements deux a deux : la lettre d'abord puis la couleur
            Forme *forme=creer_forme(lettre, couleur);
            liste_ajout_fin(liste, forme, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange); // on recrée la liste a partir des données
        }
    }
    int i=0;
    while (fgets(ligne, sizeof(ligne), f)!=NULL && i<5){ //lecture de la deuxieme liste 
        if (sscanf(ligne, "%c %d ", &lettre, &couleur)==2){ 
            Forme *forme=creer_forme(lettre, couleur);
            liste_ajout_fin_L_5_pieces(L_5_pièces, forme);
            i++;
        }
    }
    afficher_liste(liste);
    printf("\n\n");
    fclose(f);
}


void initialisation_scores(const char *nomfichier) {
    FILE *f = fopen(nomfichier, "r");
    if (f == NULL) { // on vérifie si le fichier existe deja. S'il nexiste pas on met des valeurs par defaut.
        f = fopen(nomfichier, "w");
        for (int i = 0; i < 10; i++) {
            fprintf(f, "Incconu : %d\n", 0);
        }
    }
    fclose(f);
}


void ajouter_score(const char *nomfichier, int score, char prénom[] ){ 
    FILE *f=fopen(nomfichier, "r");
    char ligne[100];
    char nom[10][30];
    int score_fichier[10];
    int position=0;
    int i=0;
    while (fgets(ligne, sizeof(ligne), f)!=NULL){
        if (sscanf(ligne, "%s : %d ", nom[i], &score_fichier[i])==2){
            if (score < score_fichier[i]){
                position ++; // on incremente le compteur pour connaitre le classement du joueur
            }
            i++;
        }
    }
    fclose(f);
    if (position>10){ //hors classement
        return;
    }
    else{
        FILE *fichier=fopen(nomfichier, "w");
        if (fichier == NULL) {
            printf("Erreur lors de l'ouverture du fichier en écriture.\n");
            return;
        }
        for (int i=0; i<position; i++){ 
            fprintf(fichier, "%s : %d\n", nom[i], score_fichier[i]); // on rajoute les scores du fichier jusqu'a la position du joueur
        }
        fprintf(fichier, "%s : %d\n", prénom, score); // arrivé a cette position, on rajoute le score du joueur ( et son nom)
        for (int i = position; i < 10; i++) {
            fprintf(fichier, "%s : %d\n", nom[i], score_fichier[i]); // on rajoute les autres scores du fichier 
        }
        fclose(fichier);
    }
}


void insertion_liste( Liste *liste, Liste * L_5_pièces, int score, char prénom[], Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange ){
    	Forme* forme;
    	srand(time(0));
        char direction;
	    while(liste->taille<15) {
	    	forme = L_5_pièces->tete->val;
                printf( "5 prochaines pieces : ");
                afficher_liste_5_pieces(L_5_pièces);
	    	printf("\n");
                printf("prochaine pièce: ");
                int erreur=1;  //variable qui permet de savoir qd le joueur tape une mauvaise commande et donc de revnir ici sans recreer une nouvelle forme
	    		while(erreur==1){ 
                    afficher_forme(forme);
                    printf("\n");
                    printf("score : "); 
                    printf("%d\n", score);
                    printf("Gauche (G) ou Droite (D) ? ou decalage? (O pour oui)");
                    scanf(" %c",&direction);
                    getchar(); //  sinon ca affichait deux fois consectuvives : "C Gauche (G) ou Droite (D)?"  
                        if ((direction =='G') || (direction == 'g')) { 
                            liste_ajout_debut(liste,forme,  L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                            int taille=liste->taille; // on stocke la taille de la liste avant qu'elle ne soit modifiée en appelant sup(liste)
                            sup(liste);
                            MAJ_generale(liste,  L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange );
                            score= Score(score, liste, taille, 's'); //la taille qu'on a stocké nous sert ici pour le score (pour connaitre le nombre délements supprimes)
                            erreur=0; // on met erreur a 0 pour sortir de la boucle et créer une nouvelle forme
                            afficher_liste(liste);
                        }
                        else if ((direction =='D') || (direction == 'd')) {
                            liste_ajout_fin(liste,forme, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                            int taille=liste->taille;
                            sup(liste);
                            MAJ_generale(liste,  L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange );
                            score= Score(score, liste, taille, 's');
                            erreur=0;
                        }
                        else if((direction =='O') || (direction == 'o')){
                            choix_decalage(liste, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                            int supp=1;
                            while(supp==1){ // tant que la taille de la liste est modifiee(cad tant qu il ya encore des elements supprimés)
                                int taille=liste->taille;
                                sup(liste);
                                score= Score(score, liste, taille, 'd');
                                if ((liste->taille)==taille){ // si la taille de la liste apres avoir appele sup(liste) est egal a la taille initiale de la liste alors aucun element a ete supprime et donc pas besoin de rappeler la fonction
                                    supp=0;
                                }
                            }
                            afficher_liste_5_pieces(liste); 
                            printf ("\n\nPièce : ");// on doit afficher l'ancienne forme car le joueur a fait un decalage et n'a pas inseré la forme 
                            if (liste->taille==0){
                                debut_jeu(liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange );
                            }
                            MAJ_generale(liste,  L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange );
                            
                        }
                        else if(direction=='S' || direction == 's'){ //sauvegarde
                            sauvegarde_jeu("sauvegarde.txt", score, liste, L_5_pièces);
                            printf("Partie sauvegardée avec succès.");
                            ajouter_score("scores.txt", score, prénom);
                            liberation_generale(liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                            return;
                        }
                        else if(direction=='F' || direction == 'f'){ //fin du jeu
                            printf("Fin du jeu !");
                            ajouter_score("scores.txt", score, prénom);
                            liberation_generale(liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                            return; 
                        }
                        else {
                            printf("Commande non valide. Veuillez saisir une autre commande ou quiitez le jeu en appuyant sur 'F'.\n\n");
                            printf("pièce : ");
                        }
                }
                decalage_Liste_5(L_5_pièces); // on a pris le maillon de la tete de la liste pour le mettre dans la liste principale. Il faut donc appeler decalage pour generer un nouveau maillon dans la liste des 5 pièces
                if (liste->taille==0){
	    				debut_jeu(liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange );
	    		}
	    		else{
                    afficher_liste(liste);
                    printf("\n\n"); 
                    if (liste->taille==15){
                        ajouter_score("scores.txt", score, prénom);
                        printf("Game over... plus de place sur le plateau \n");
                        liberation_generale(liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
                    }    
                }
	    }
}


void choix_joueur(Liste *liste, int score, Liste * L_5_pièces, Double_Liste *L_rouge, Double_Liste *L_bleu, Double_Liste *L_vert, Double_Liste *L_jaune, Double_Liste *L_carre, Double_Liste *L_rond, Double_Liste *L_triangle, Double_Liste *L_losange ){
    printf("Etes vous pret ? Allons y ! \n\n");
    char choix;
    char prénom [50];
    printf("Quel est votre prénom ? ");
    scanf("%s", prénom);
    printf("Voulez vous reprendre une ancienne partie? Répondez par 'O'(Oui) ou par 'N'(Non) ");
    scanf(" %c", &choix );
    if (choix == 'O' || choix== 'o'){
        printf("C'est parti, reprenons l'ancienne partie");
        charger_jeu("sauvegarde.txt", &score, liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
        liste->taille++;
        L_5_pièces->taille++;
        insertion_liste(liste, L_5_pièces, score, prénom, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
    }
    else {
        initialisation_Liste_5(L_5_pièces);
        debut_jeu(liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
        insertion_liste(liste, L_5_pièces, score , prénom, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
    }
}


int main(){
    Double_Liste *L_vert=double_liste_init();
    Double_Liste *L_bleu=double_liste_init();
    Double_Liste *L_rouge=double_liste_init();
    Double_Liste *L_jaune=double_liste_init();
    Double_Liste *L_carre=double_liste_init();
    Double_Liste *L_triangle=double_liste_init();
    Double_Liste *L_losange=double_liste_init();
    Double_Liste *L_rond=double_liste_init();
    Liste *liste = liste_init();
    Liste *L_5_pièces= liste_init();
    initialisation_scores("scores.txt");
    int score=0;
    choix_joueur(liste, score, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
	//liberation_generale(liste, L_5_pièces, L_rouge, L_bleu, L_vert, L_jaune, L_carre, L_rond, L_triangle, L_losange);
}
			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			

	
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			
    			


