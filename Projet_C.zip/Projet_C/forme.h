#ifndef FORME_H
        #define FORME_H
        #include <stdio.h>
        typedef struct {
        char lettre;
        int couleur;
        } Forme;

    Forme *creer_forme(char lettre, int couleur);

    void afficher_forme(Forme *f);

    void libere_forme(Forme *f);

#endif


