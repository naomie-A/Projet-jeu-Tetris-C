#ifndef LIST_H
	#define LIST_H
	#include "forme.h"
	#include <stdio.h>
	
	typedef struct maillon {
		Forme *val;
		struct maillon *suiv;
        struct maillon *suiv_couleur;
		struct maillon *prec_couleur;
		struct maillon *suiv_lettre;
		struct maillon *prec_lettre;
		} Maillon;

	typedef struct liste {
		int taille;
		Maillon *tete;
		Maillon *queue;
		} Liste;


    typedef struct double_list{
		int taille;
		Maillon *tete_couleur;
		Maillon *queue_couleur;
        Maillon *tete_lettre;
	    Maillon *queue_lettre;
     }Double_Liste;
     
    
	Liste *liste_init(void);
	
    Maillon *Maillon_init(void);

	void afficher_liste(Liste *liste);

	void liberation_liste(Liste *L);

    Double_Liste *double_liste_init(void);

	void supression_precise(Liste *L, int indice, int cpt, Maillon *M);

	void sup(Liste *L);

	void afficher_liste_5_pieces(Liste *liste);
	
#endif
