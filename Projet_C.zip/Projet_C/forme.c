#include "forme.h"
#include <stdio.h>
#include <stdlib.h>

Forme *creer_forme(char lettre, int couleur) {
        Forme *res = malloc(sizeof(Forme));
        if (res == NULL) return NULL;
        res->lettre= lettre;
    	res->couleur= couleur;
    	return res;
}

void afficher_forme(Forme *f){
    printf("\033[%dm%c ", f -> couleur, f -> lettre );
    printf("\033[39m");
    
}

void libere_forme(Forme *f) {
        free(f);
}
